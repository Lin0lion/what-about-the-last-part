ServerEvents.recipes(event => {
	event.shaped('minecraft:enchanted_golden_apple', [
		'BBB',
		'BAB',
		'BBB'
	],{
		B: 'minecraft:gold_block',
		A: 'minecraft:apple'
	})
	// The classic 1.8 enchanted golden apple recipe.
	// You can get more yet at a more expensive price if you use the Avaritia Delight's extreme cooking.
});

ServerEvents.recipes(event => {
	event.shapeless('avaritia_delight:diamond_lattice_potato', [
		'avaritia:diamond_lattice',
		'minecraft:potato'
	])
	// 
});

ServerEvents.recipes(event => {
	event.shaped('avaritia_delight:blaze_tomato_seeds', [
		'BBB',
		'BAB',
		'BBB'
	],{
		A: 'farmersdelight:tomato_seeds',
		B: 'minecraft:blaze_powder'
	})
	event.shaped('avaritia_delight:blaze_tomato_seeds', [
		' B ',
		'BAB',
		' B '
	],{
		A: 'farmersdelight:tomato_seeds',
		B: 'minecraft:blaze_rod'
	})
	// Avaritia Delight isn't finished yet, but I wanted to add this recipe.
// In fact, it's one of the only things from Avaritia Delight that can actually be eaten right now,
// so I decided, why not? Also, there's also a second recipe using blaze rods instead of blaze powder.
});

ProjectEEvents.setEMC(event => {
	event.setEMC("minecraft:wither_skeleton_skull", 10880);
	// This number was made by multiplying  the EMC of coal (128) by 40,
	// and then multipling the EMC of bones (144) by 40 as well, then adding the two together.
	// The number 40 was chosen because wither skeleton skulls have around a 2.5% chance to drop.
	// So, 40 coal + 40 bones = 1 wither skeleton skull, in theory.
	// 128 * 40 = 5120, 144 * 40 = 5760, 5120 + 5760 = 10880.
	// It's called "maths", kid. It's so complicated! (not)
})

// This was coded using Visual Studio Code, although the first bit was done in the normal Windows 10 Notepad.
// Also, I'm not very good at coding, so I used Liopyu's first episode on KubeJS (https://www.youtube.com/watch?v=xhJJbNJjics).
// And a big thank you to the Claude AI for helping fix a few (correction:a lot of) mistakes I made!